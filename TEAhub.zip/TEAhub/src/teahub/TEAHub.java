package teahub;

import br.com.teahub.view.CadastroView; 
import javax.swing.UIManager;

public class TEAHub {

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("FlatLaf Light".equals(info.getName())) { 
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {}
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                CadastroView telaCadastro = new CadastroView();
                telaCadastro.setLocationRelativeTo(null);
                telaCadastro.setVisible(true);
            }
        });
      
    }
}