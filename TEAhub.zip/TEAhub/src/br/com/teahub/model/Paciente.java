package br.com.teahub.model;

import java.time.LocalDate;

public class Paciente {
    private int idPaciente;
    private Clinica clinica;
    private String nomePaciente;
    private LocalDate dataNascimento;
    private String responsavel;
    private String telefoneResponsavel;
    private int nivelTea;
    private boolean statusAtivo;
    private String medicacoesEmUso;
    private String restricoesAlimentares;
    private LocalDate dataCadastro;

    public Paciente() {
    }

    public Paciente(Clinica clinica, String nomePaciente, LocalDate dataNascimento, String responsavel, String telefoneResponsavel, int nivelTea, boolean statusAtivo) {
        this.clinica = clinica;
        this.nomePaciente = nomePaciente;
        this.dataNascimento = dataNascimento;
        this.responsavel = responsavel;
        this.telefoneResponsavel = telefoneResponsavel;
        this.nivelTea = nivelTea;
        this.statusAtivo = statusAtivo;
    }
    
    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public Clinica getClinica() {
        return clinica;
    }

    public void setClinica(Clinica clinica) {
        this.clinica = clinica;
    }

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getTelefoneResponsavel() {
        return telefoneResponsavel;
    }

    public void setTelefoneResponsavel(String telefoneResponsavel) {
        this.telefoneResponsavel = telefoneResponsavel;
    }

    public int getNivelTea() {
        return nivelTea;
    }

    public void setNivelTea(int nivelTea) {
        this.nivelTea = nivelTea;
    }

    public boolean isStatusAtivo() {
        return statusAtivo;
    }

    public void setStatusAtivo(boolean statusAtivo) {
        this.statusAtivo = statusAtivo;
    }
    
    
    public String getMedicacoesEmUso() {
        return medicacoesEmUso;
    }

    public void setMedicacoesEmUso(String medicacoesEmUso) {
        this.medicacoesEmUso = medicacoesEmUso;
    }

    public String getRestricoesAlimentares() {
        return restricoesAlimentares;
    }

    public void setRestricoesAlimentares(String restricoesAlimentares) {
        this.restricoesAlimentares = restricoesAlimentares;
    }

    public LocalDate getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDate dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
}
