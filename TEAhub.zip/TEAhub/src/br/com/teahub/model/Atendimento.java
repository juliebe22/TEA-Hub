package br.com.teahub.model;

import java.time.LocalDateTime;

public class Atendimento {
    private int idAtendimento;
    private Profissional profissional; 
    private Paciente paciente;         
    private LocalDateTime dataAtendimento;
    private String observacoes;

    public Atendimento() {
    }

    public Atendimento(int idAtendimento, Profissional profissional, Paciente paciente) {
        this.idAtendimento = idAtendimento;
        this.profissional = profissional;
        this.paciente = paciente;
    }

    public int getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(int idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Profissional getProfissional() {
        return profissional;
    }

    public void setProfissional(Profissional profissional) {
        this.profissional = profissional;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public LocalDateTime getDataAtendimento() {
        return dataAtendimento;
    }

    public void setDataAtendimento(LocalDateTime dataAtendimento) {
        this.dataAtendimento = dataAtendimento;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }
}
