package br.com.teahub.model;

public class Clinica {
    private int idClinica;
    private String nomeClinica;
    private String cnpj;
    private String usuarioAdmin;
    private String senhaAdmin;
    private String telefone;

    public Clinica() {}
    
    public Clinica(int idClinica, String nomeClinica, String usuarioAdmin) {
        this.idClinica = idClinica;
        this.nomeClinica = nomeClinica;
        this.usuarioAdmin = usuarioAdmin;
    }
    
    public int getIdClinica() { 
        return idClinica; 
    }
    public void setIdClinica(int idClinica) { 
        this.idClinica = idClinica; 
    }

    public String getNomeClinica() { 
        return nomeClinica; 
    }
    public void setNomeClinica(String nomeClinica) { 
        this.nomeClinica = nomeClinica; 
    }

    public String getCnpj() { 
        return cnpj; 
    }
    public void setCnpj(String cnpj) { 
        this.cnpj = cnpj; 
    }

    public String getUsuarioAdmin() { 
        return usuarioAdmin; 
    }
    public void setUsuarioAdmin(String usuarioAdmin) { 
        this.usuarioAdmin = usuarioAdmin; 
    }

    public String getSenhaAdmin() { 
        return senhaAdmin; 
    }
    public void setSenhaAdmin(String senhaAdmin) { 
        this.senhaAdmin = senhaAdmin; 
    }

    public String getTelefone() { 
        return telefone; 
    }
    public void setTelefone(String telefone) { 
        this.telefone = telefone; 
    }
}
