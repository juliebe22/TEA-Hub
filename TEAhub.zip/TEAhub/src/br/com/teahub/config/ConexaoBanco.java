package br.com.teahub.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBanco {
    private static final String URL = "jdbc:postgresql://localhost:5432/TEAHub";
    private static final String USER = "postgres";
    private static final String PASSWORD = "1230";

    public static Connection conectar() {
        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
            
        } catch (ClassNotFoundException e) {
            System.out.println("\n[ERRO DE CONEXÃO]: O Driver do PostgreSQL não foi encontrado nas bibliotecas do projeto!");
            e.printStackTrace(); 
            return null;
        } catch (SQLException e) {
            System.out.println("\n========================================================");
            System.out.println("[ERRO DE CONEXÃO]: Falha ao conectar ao PostgreSQL.");
            System.out.println("Motivo real: " + e.getMessage());
            System.out.println("Código de Estado SQL: " + e.getSQLState());
            System.out.println("Verifique: 1. Se a senha está correta.");
            System.out.println("           2. Se o nome do banco está idêntico ao criado no pgAdmin.");
            System.out.println("           3. Se o serviço do PostgreSQL está ativo no seu computador.");
            System.out.println("========================================================\n");
            e.printStackTrace(); 
            return null;
        }
    }

    public static void main(String[] args) {
        System.out.println("Iniciando teste de conexão isolado...");
        Connection conn = conectar();
        
        if (conn != null) {
            System.out.println("\n[SUCESSO]: O Java conectou perfeitamente ao banco TEAHub!");
            try {
                conn.close(); 
            } catch (SQLException ex) {
            }
        } else {
            System.out.println("\n[FALHA]: A conexão retornou null. Olhe as mensagens de erro detalhadas acima.");
        }
    }
}