package br.com.teahub.util;

import br.com.teahub.model.Profissional;

public class Sessao {
    private static Profissional profissionalLogado;

    public static void setLogado(Profissional p) {
        profissionalLogado = p;
    }

    public static Profissional getLogado() {
        return profissionalLogado;
    }

    public static int getIdLogado() {
        if (profissionalLogado == null) return -1;
        return profissionalLogado.getIdProfissional();
    }

    public static void encerrar() {
        profissionalLogado = null;
    }

}