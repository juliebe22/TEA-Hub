package br.com.teahub.view;
import br.com.teahub.dao.ProfissionalDAO;
import br.com.teahub.model.Profissional;
import br.com.teahub.util.Sessao;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ContaView extends JPanel {

    private JTextField txtNome, txtEmail, txtEspecialidade, txtRegistro;
    private JPasswordField txtSenha;
    private JLabel lblStatus;
    private JLabel lblBadgeStatus;
    private Timer timerStatus;

    private final ProfissionalDAO dao = new ProfissionalDAO();

    private final Color COR_PRIMARIA  = new Color(0, 128, 128);
    private final Color COR_VERMELHO  = new Color(180, 50, 50);
    private final Color COR_VERDE     = new Color(34, 150, 80);
    private final Color COR_FUNDO     = new Color(245, 245, 250);
    private final Color COR_BRANCO    = Color.WHITE;
    private final Color COR_BORDA     = new Color(200, 200, 220);

    public ContaView() {
        setLayout(new BorderLayout());
        setBackground(COR_FUNDO);

        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        painelPrincipal.setBackground(COR_FUNDO);
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0; g.gridy = 0; g.weightx = 1;

        painelPrincipal.add(criarCartaoPerfil(), g);

        JScrollPane scroll = new JScrollPane(painelPrincipal);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        carregarDados();
    }

    private JPanel criarCartaoPerfil() {
        JPanel cartao = new JPanel(new GridBagLayout());
        cartao.setBackground(COR_BRANCO);
        cartao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COR_BORDA),
                BorderFactory.createEmptyBorder(40, 60, 40, 60)));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(10, 10, 10, 10);
        g.weightx = 1;

        // ── Cabeçalho com circulo + nome + badge ──────────────
        JPanel cabecalho = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        cabecalho.setBackground(COR_BRANCO);

        // Circulo com inicial
        JPanel circulo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g2) {
                super.paintComponent(g2);
                Graphics2D g = (Graphics2D) g2;
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(COR_PRIMARIA);
                g.fillOval(0, 0, 70, 70);
                g.setColor(Color.WHITE);
                g.setFont(new Font("Segoe UI", Font.BOLD, 28));
                FontMetrics fm = g.getFontMetrics();
                String inicial = (txtNome != null && !txtNome.getText().isBlank())
                        ? String.valueOf(txtNome.getText().charAt(0)).toUpperCase() : "P";
                g.drawString(inicial, (70 - fm.stringWidth(inicial)) / 2,
                        (70 - fm.getHeight()) / 2 + fm.getAscent());
            }
        };
        circulo.setPreferredSize(new Dimension(70, 70));
        circulo.setOpaque(false);

        // Painel com titulo + subtitulo + badge
        JPanel infoHeader = new JPanel();
        infoHeader.setLayout(new BoxLayout(infoHeader, BoxLayout.Y_AXIS));
        infoHeader.setBackground(COR_BRANCO);

        JLabel lblTitulo = new JLabel("Perfil do Profissional");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(COR_PRIMARIA);

        JLabel lblSub = new JLabel("Gerencie suas informacoes pessoais e de acesso");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(new Color(120, 120, 140));

        // Badge de status — começa vazio, preenchido ao carregar
        lblBadgeStatus = new JLabel("  Profissional Ativo  ") {
            @Override
            protected void paintComponent(Graphics g2) {
                Graphics2D g = (Graphics2D) g2;
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(getBackground());
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                super.paintComponent(g2);
            }
        };
        lblBadgeStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblBadgeStatus.setForeground(Color.WHITE);
        lblBadgeStatus.setBackground(COR_VERDE);
        lblBadgeStatus.setOpaque(false);
        lblBadgeStatus.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));

        infoHeader.add(lblTitulo);
        infoHeader.add(Box.createVerticalStrut(4));
        infoHeader.add(lblSub);
        infoHeader.add(Box.createVerticalStrut(8));
        infoHeader.add(lblBadgeStatus);

        cabecalho.add(circulo);
        cabecalho.add(infoHeader);

        g.gridx = 0; g.gridy = 0; g.gridwidth = 4;
        cartao.add(cabecalho, g);

        // Separador
        JSeparator sep = new JSeparator();
        sep.setForeground(COR_BORDA);
        g.gridy = 1; g.insets = new Insets(10, 10, 20, 10);
        cartao.add(sep, g);

        // ── Seção: Informações Pessoais ────────────────────────
        g.insets = new Insets(10, 10, 8, 10);
        JLabel lblSecao1 = new JLabel("Informacoes Pessoais");
        lblSecao1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblSecao1.setForeground(new Color(60, 60, 80));
        g.gridy = 2; g.gridwidth = 4;
        cartao.add(lblSecao1, g);

        g.gridwidth = 2; g.insets = new Insets(6, 10, 6, 10);

        g.gridx = 0; g.gridy = 3;
        cartao.add(criarLabel("Nome completo"), g);
        g.gridx = 2;
        cartao.add(criarLabel("E-mail"), g);

        txtNome  = criarCampo(true);
        txtEmail = criarCampo(true);

        g.gridx = 0; g.gridy = 4;
        cartao.add(txtNome, g);
        g.gridx = 2;
        cartao.add(txtEmail, g);

        g.gridx = 0; g.gridy = 5;
        cartao.add(criarLabel("Especialidade"), g);
        g.gridx = 2;
        cartao.add(criarLabel("Registro Profissional"), g);

        txtEspecialidade = criarCampo(true);
        txtRegistro      = criarCampo(true);

        g.gridx = 0; g.gridy = 6;
        cartao.add(txtEspecialidade, g);
        g.gridx = 2;
        cartao.add(txtRegistro, g);

        // ── Seção: Segurança ───────────────────────────────────
        g.gridx = 0; g.gridy = 7; g.gridwidth = 4;
        g.insets = new Insets(25, 10, 8, 10);
        JLabel lblSecao2 = new JLabel("Seguranca");
        lblSecao2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblSecao2.setForeground(new Color(60, 60, 80));
        cartao.add(lblSecao2, g);

        JSeparator sep2 = new JSeparator();
        sep2.setForeground(COR_BORDA);
        g.gridy = 8; g.insets = new Insets(0, 10, 15, 10);
        cartao.add(sep2, g);

        g.gridx = 0; g.gridy = 9; g.gridwidth = 2;
        g.insets = new Insets(6, 10, 6, 10);
        cartao.add(criarLabel("Nova senha de acesso"), g);

        txtSenha = new JPasswordField();
        txtSenha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSenha.setPreferredSize(new Dimension(0, 38));
        txtSenha.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COR_BORDA),
                BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        g.gridy = 10;
        cartao.add(txtSenha, g);

        JLabel lblDica = new JLabel("Ao digitar e atualizar sua senha mudará.");
        lblDica.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblDica.setForeground(new Color(150, 150, 170));
        g.gridy = 11;
        cartao.add(lblDica, g);

        // ── Status e Botões ────────────────────────────────────
        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
        g.gridx = 0; g.gridy = 12; g.gridwidth = 4;
        g.insets = new Insets(20, 10, 5, 10);
        cartao.add(lblStatus, g);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        painelBotoes.setBackground(COR_BRANCO);

        JButton btnAtualizar = criarBotao("Salvar alteracoes", COR_PRIMARIA);
        JButton btnDeletar   = criarBotao("Deletar conta",     COR_VERMELHO);

        btnAtualizar.addActionListener(e -> atualizar());
        btnDeletar.addActionListener(e -> deletar());

        painelBotoes.add(btnDeletar);
        painelBotoes.add(btnAtualizar);

        g.gridy = 13; g.insets = new Insets(10, 10, 0, 10);
        cartao.add(painelBotoes, g);

        return cartao;
    }

    private void carregarDados() {
        lblStatus.setText(" ");
        int id = Sessao.getIdLogado();
        if (id == -1) {
            mostrarStatus("Nenhum profissional logado.", COR_VERMELHO, false);
            return;
        }
        Profissional p = dao.buscarPorId(id);
        if (p != null) {
            txtNome.setText(p.getNome());
            txtEmail.setText(p.getEmail());
            txtEspecialidade.setText(p.getEspecialidade());
            txtRegistro.setText(p.getRegistroProfissional());
            txtSenha.setText("");

            // Atualiza o badge de status
            if (p.isStatusAtivo()) {
                lblBadgeStatus.setText("  Profissional Ativo  ");
                lblBadgeStatus.setBackground(COR_VERDE);
            } else {
                lblBadgeStatus.setText("  Profissional Inativo  ");
                lblBadgeStatus.setBackground(COR_VERMELHO);
            }
            lblBadgeStatus.repaint();
        } else {
            mostrarStatus("Nao foi possivel carregar os dados.", COR_VERMELHO, false);
        }
    }

    private void atualizar() {
    if (txtNome.getText().isBlank() || txtEmail.getText().isBlank()
            || txtEspecialidade.getText().isBlank()) {
        mostrarStatus("Preencha todos os campos obrigatórios.", COR_VERMELHO, true);
        return;
    }

    // 1. Recupera o profissional da sessão para manter os dados existentes (como a Clínica)
    Profissional p = Sessao.getLogado();
    
    if (p == null) {
        mostrarStatus("Erro: Sessão expirada.", COR_VERMELHO, true);
        return;
    }

    // 2. Atualiza apenas os campos que podem mudar
    p.setNome(txtNome.getText().trim());
    p.setEmail(txtEmail.getText().trim());
    p.setEspecialidade(txtEspecialidade.getText().trim());
    p.setRegistroProfissional(txtRegistro.getText().trim());
    
    String novaSenha = new String(txtSenha.getPassword()).trim();
    if (!novaSenha.isBlank()) {
        p.setSenhaLogin(novaSenha);
    }

    // 3. Executa a atualização
    if (dao.atualizar(p)) {
        txtSenha.setText("");
        // Atualiza a sessão com os dados modificados
        Sessao.setLogado(p); 
        mostrarStatus("Dados atualizados com sucesso!", COR_VERDE, true);
    } else {
        mostrarStatus("Erro ao atualizar os dados.", COR_VERMELHO, true);
    }
}

    private void mostrarStatus(String msg, Color cor, boolean autoSumir) {
        lblStatus.setText(msg);
        lblStatus.setForeground(cor);
        if (timerStatus != null && timerStatus.isRunning()) timerStatus.stop();
        if (autoSumir) {
            timerStatus = new Timer(3000, (ActionEvent e) -> lblStatus.setText(" "));
            timerStatus.setRepeats(false);
            timerStatus.start();
        }
    }

    private void deletar() {
        int confirma = JOptionPane.showConfirmDialog(this,
                "Tem certeza que deseja deletar sua conta?\nEssa acao nao pode ser desfeita.",
                "Confirmar exclusao", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirma == JOptionPane.YES_OPTION) {
            if (dao.excluir(Sessao.getIdLogado())) {
                JOptionPane.showMessageDialog(this, "Conta desativada. O sistema sera encerrado.");
                System.exit(0);
            } else {
                mostrarStatus("Erro ao deletar a conta.", COR_VERMELHO, true);
            }
        }
    }

    public void recarregar() {
        carregarDados();
    }

    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(80, 80, 100));
        return label;
    }

    private JTextField criarCampo(boolean editavel) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setPreferredSize(new Dimension(0, 38));
        tf.setEditable(editavel);
        tf.setBackground(editavel ? COR_BRANCO : new Color(235, 235, 240));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COR_BORDA),
                BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        return tf;
    }

    private JButton criarBotao(String texto, Color cor) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(cor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        return btn;
    }
}