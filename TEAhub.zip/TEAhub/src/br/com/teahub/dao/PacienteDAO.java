package br.com.teahub.dao;

import br.com.teahub.config.ConexaoBanco; 
import br.com.teahub.model.Clinica;
import br.com.teahub.model.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO implements DAO<Paciente> {

    @Override
    public boolean cadastrar(Paciente paciente) {
        String sql = "INSERT INTO paciente (nome_paciente, data_nascimento, responsavel, telefone_responsavel, nivel_tea, status_ativo, id_clinica) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, paciente.getNomePaciente());
                stmt.setDate(2, Date.valueOf(paciente.getDataNascimento()));
                stmt.setString(3, paciente.getResponsavel());
                stmt.setString(4, paciente.getTelefoneResponsavel());
                stmt.setInt(5, paciente.getNivelTea());
                stmt.setBoolean(6, paciente.isStatusAtivo());
                stmt.setInt(7, paciente.getClinica().getIdClinica()); 
                
                stmt.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[Erro PacienteDAO] Falha ao cadastrar: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean atualizar(Paciente paciente) {
        String sql = "UPDATE paciente SET nome_paciente = ?, data_nascimento = ?, responsavel = ?, telefone_responsavel = ?, nivel_tea = ?, status_ativo = ? WHERE id_paciente = ?";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, paciente.getNomePaciente());
                stmt.setDate(2, Date.valueOf(paciente.getDataNascimento()));
                stmt.setString(3, paciente.getResponsavel());
                stmt.setString(4, paciente.getTelefoneResponsavel());
                stmt.setInt(5, paciente.getNivelTea());
                stmt.setBoolean(6, paciente.isStatusAtivo());
                stmt.setInt(7, paciente.getIdPaciente());
                
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro PacienteDAO] Falha ao atualizar: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean excluir(int idPaciente) { 
        String sql = "DELETE FROM paciente WHERE id_paciente = ?";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idPaciente);
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro PacienteDAO] Falha ao deletar: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Paciente> listar(int idClinica, String busca) {
        List<Paciente> lista = new ArrayList<>();
        String sql = (busca == null || busca.trim().isEmpty())
                ? "SELECT * FROM paciente WHERE id_clinica = ? ORDER BY nome_paciente"
                : "SELECT * FROM paciente WHERE id_clinica = ? AND nome_paciente ILIKE ? ORDER BY nome_paciente";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return lista;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idClinica);
                if (busca != null && !busca.trim().isEmpty()) {
                    stmt.setString(2, "%" + busca + "%");
                }
                
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Paciente p = new Paciente();
                        p.setIdPaciente(rs.getInt("id_paciente"));
                        p.setNomePaciente(rs.getString("nome_paciente"));
                        p.setDataNascimento(rs.getDate("data_nascimento").toLocalDate());
                        p.setResponsavel(rs.getString("responsavel"));
                        p.setTelefoneResponsavel(rs.getString("telefone_responsavel"));
                        p.setNivelTea(rs.getInt("nivel_tea"));
                        p.setStatusAtivo(rs.getBoolean("status_ativo"));
                        
                        Clinica c = new Clinica();
                        c.setIdClinica(rs.getInt("id_clinica"));
                        p.setClinica(c);
                        
                        lista.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[Erro PacienteDAO] Falha ao listar/filtrar pacientes: " + e.getMessage());
        }
        return lista;
    }

    public boolean desativar(int idPaciente) {
        String sql = "UPDATE paciente SET status_ativo = false WHERE id_paciente = ?";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idPaciente);
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro PacienteDAO] Falha ao desativar: " + e.getMessage());
            return false;
        }
    }
    
    public List<Paciente> listarTodosParaSeletor() {
        List<Paciente> lista = new ArrayList<>();
        String sql = "SELECT id_paciente, nome_paciente FROM paciente ORDER BY nome_paciente";
        
        try (Connection conn = ConexaoBanco.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            if (conn == null) return lista;
            
            while (rs.next()) {
                Paciente p = new Paciente();
                p.setIdPaciente(rs.getInt("id_paciente"));
                p.setNomePaciente(rs.getString("nome_paciente"));
                lista.add(p);
            }
        } catch (SQLException e) {
            System.err.println("[Erro PacienteDAO] Falha no seletor geral: " + e.getMessage());
        }
        return lista;
    }
}