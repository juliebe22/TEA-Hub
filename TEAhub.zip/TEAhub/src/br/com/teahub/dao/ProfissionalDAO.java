package br.com.teahub.dao;

import br.com.teahub.config.ConexaoBanco; 
import br.com.teahub.model.Profissional;
import br.com.teahub.model.Clinica;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProfissionalDAO implements DAO<Profissional> {

    @Override
    public boolean cadastrar(Profissional profissional) {
        String sql = "INSERT INTO profissional (id_clinica, nome, email, usuario_login, senha_login, especialidade, registro_profissional) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, profissional.getClinica().getIdClinica());
                stmt.setString(2, profissional.getNome());
                stmt.setString(3, profissional.getEmail());
                stmt.setString(4, profissional.getUsuarioLogin()); 
                stmt.setString(5, profissional.getSenhaLogin());
                stmt.setString(6, profissional.getEspecialidade());
                stmt.setString(7, profissional.getRegistroProfissional());

                stmt.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[Erro ProfissionalDAO] Falha ao cadastrar: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean atualizar(Profissional profissional) {
        String sql = "UPDATE profissional SET id_clinica = ?, nome = ?, email = ?, usuario_login = ?, senha_login = ?, especialidade = ?, registro_profissional = ?, status_ativo = ? WHERE id_profissional = ?";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                // Proteção para evitar o NullPointerException
                if (profissional.getClinica() != null) {
                    stmt.setInt(1, profissional.getClinica().getIdClinica());
                } else {
                    stmt.setNull(1, java.sql.Types.INTEGER);
                }
                
                stmt.setString(2, profissional.getNome());
                stmt.setString(3, profissional.getEmail());
                stmt.setString(4, profissional.getUsuarioLogin());
                stmt.setString(5, profissional.getSenhaLogin());
                stmt.setString(6, profissional.getEspecialidade());
                stmt.setString(7, profissional.getRegistroProfissional());
                stmt.setBoolean(8, profissional.isStatusAtivo());
                stmt.setInt(9, profissional.getIdProfissional());
                
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro ProfissionalDAO] Falha ao atualizar: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean excluir(int idProfissional) {
        String sql = "DELETE FROM profissional WHERE id_profissional = ?";
        
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idProfissional);
                return stmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro ProfissionalDAO] Falha ao deletar: " + e.getMessage());
            return false;
        }
    }

    public Profissional buscarPorLogin(String usuario, String senha) {
        String sql = "SELECT * FROM profissional WHERE usuario_login = ? AND senha_login = ? AND status_ativo = TRUE";
        try (Connection conn = ConexaoBanco.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (conn == null) return null;
            stmt.setString(1, usuario); 
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Profissional p = mapResultSetToProfissional(rs);
                return p;
            }
        } catch (SQLException e) { System.err.println("[Erro] Login: " + e.getMessage()); }
        return null;
    }

    public Profissional buscarPorId(int idProfissional) {
        String sql = "SELECT * FROM profissional WHERE id_profissional = ?";
        try (Connection conn = ConexaoBanco.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (conn == null) return null;
            stmt.setInt(1, idProfissional);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToProfissional(rs);
            }
        } catch (SQLException e) { System.err.println("[Erro] BuscarPorId: " + e.getMessage()); }
        return null;
    }
    
    // Método auxiliar para não repetir código de mapeamento
    private Profissional mapResultSetToProfissional(ResultSet rs) throws SQLException {
        Profissional p = new Profissional();
        p.setIdProfissional(rs.getInt("id_profissional"));
        p.setNome(rs.getString("nome"));
        p.setEmail(rs.getString("email"));
        p.setEspecialidade(rs.getString("especialidade"));
        p.setRegistroProfissional(rs.getString("registro_profissional"));
        p.setStatusAtivo(rs.getBoolean("status_ativo"));
        p.setUsuarioLogin(rs.getString("usuario_login"));
        p.setSenhaLogin(rs.getString("senha_login"));
        
        // Mapeia a clínica corretamente para evitar o NullPointerException
        Clinica c = new Clinica();
        c.setIdClinica(rs.getInt("id_clinica"));
        p.setClinica(c);
        
        return p;
    }
    
    @Override
    public List<Profissional> listar(int idClinica, String busca) {
        List<Profissional> lista = new ArrayList<>();
        String sql = (busca == null || busca.trim().isEmpty())
                ? "SELECT id_profissional, nome, especialidade FROM profissional WHERE id_clinica = ? ORDER BY nome ASC"
                : "SELECT id_profissional, nome, especialidade FROM profissional WHERE id_clinica = ? AND LOWER(nome) LIKE ? ORDER BY nome ASC";

        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return lista;
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idClinica);
                if (busca != null && !busca.trim().isEmpty()) {
                    stmt.setString(2, "%" + busca.toLowerCase() + "%");
                }
                
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Profissional p = new Profissional();
                        p.setIdProfissional(rs.getInt("id_profissional")); 
                        p.setNome(rs.getString("nome"));
                        p.setEspecialidade(rs.getString("especialidade"));
                        lista.add(p);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[Erro ProfissionalDAO] Falha ao listar profissionais: " + e.getMessage());
        }
        return lista;
    }
}