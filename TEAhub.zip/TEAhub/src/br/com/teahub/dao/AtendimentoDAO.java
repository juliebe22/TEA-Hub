package br.com.teahub.dao;

import br.com.teahub.config.ConexaoBanco; 
import br.com.teahub.model.Atendimento;
import br.com.teahub.model.Paciente;
import br.com.teahub.model.Profissional;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AtendimentoDAO implements DAO<Atendimento> {

    @Override
    public boolean cadastrar(Atendimento a) {
        String sql = """
            INSERT INTO atendimento (id_paciente, id_profissional, observacoes, data_atendimento)
            VALUES (?, ?, ?, ?)
            """;
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, a.getPaciente().getIdPaciente());
                ps.setInt(2, a.getProfissional().getIdProfissional()); 
                ps.setString(3, a.getObservacoes());
                ps.setTimestamp(4, Timestamp.valueOf(a.getDataAtendimento()));
                
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro AtendimentoDAO] Falha ao cadastrar: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Atendimento a) { 
        return modificarAtendimento(a);
    }

    @Override
    public boolean atualizar(Atendimento a) {
        return modificarAtendimento(a);
    }

    private boolean modificarAtendimento(Atendimento a) {
        String sql = """
            UPDATE atendimento
               SET id_paciente = ?, id_profissional = ?, observacoes = ?, data_atendimento = ?
             WHERE id_atendimento = ?
            """;
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, a.getPaciente().getIdPaciente());
                ps.setInt(2, a.getProfissional().getIdProfissional());
                ps.setString(3, a.getObservacoes());
                ps.setTimestamp(4, Timestamp.valueOf(a.getDataAtendimento()));
                ps.setInt(5, a.getIdAtendimento());
                
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro AtendimentoDAO] Falha ao atualizar: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean excluir(int idAtendimento) {
        String sql = "DELETE FROM atendimento WHERE id_atendimento = ?";
        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return false;

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idAtendimento);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[Erro AtendimentoDAO] Falha ao excluir: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Atendimento> listar(int idClinica, String busca) {
        List<Atendimento> lista = new ArrayList<>();
        
        String sql = (busca == null || busca.trim().isEmpty()) ? """
            SELECT a.id_atendimento, a.id_paciente, a.observacoes, a.data_atendimento, 
                   p.nome_paciente, pr.id_profissional, pr.nome AS nome_profissional, pr.especialidade
              FROM atendimento a
              JOIN paciente p ON p.id_paciente = a.id_paciente
              JOIN profissional pr ON pr.id_profissional = a.id_profissional
             WHERE p.id_clinica = ?
             ORDER BY a.data_atendimento DESC
            """ : """
            SELECT a.id_atendimento, a.id_paciente, a.observacoes, a.data_atendimento, 
                   p.nome_paciente, pr.id_profissional, pr.nome AS nome_profissional, pr.especialidade
              FROM atendimento a
              JOIN paciente p ON p.id_paciente = a.id_paciente
              JOIN profissional pr ON pr.id_profissional = a.id_profissional
             WHERE p.id_clinica = ? AND p.nome_paciente ILIKE ?
             ORDER BY a.data_atendimento DESC
            """;

        try (Connection conn = ConexaoBanco.conectar()) {
            if (conn == null) return lista;

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idClinica);
                if (busca != null && !busca.trim().isEmpty()) {
                    ps.setString(2, "%" + busca + "%");
                }

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Atendimento a = new Atendimento();
                        a.setIdAtendimento(rs.getInt("id_atendimento"));
                        a.setObservacoes(rs.getString("observacoes"));

                        Paciente p = new Paciente();
                        p.setIdPaciente(rs.getInt("id_paciente"));
                        p.setNomePaciente(rs.getString("nome_paciente"));
                        a.setPaciente(p);

                        Profissional prof = new Profissional();
                        prof.setIdProfissional(rs.getInt("id_profissional"));
                        prof.setNome(rs.getString("nome_profissional"));
                        prof.setEspecialidade(rs.getString("especialidade"));
                        a.setProfissional(prof);

                        Timestamp ts = rs.getTimestamp("data_atendimento");
                        if (ts != null) {
                            a.setDataAtendimento(ts.toLocalDateTime());
                        }
                        lista.add(a);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[Erro AtendimentoDAO] Falha ao listar atendimentos: " + e.getMessage());
        }
        return lista;
    }
}