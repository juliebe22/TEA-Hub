package br.com.teahub.dao;

import java.util.List;

public interface DAO<T> {
    boolean cadastrar(T entidade);
    boolean atualizar(T objeto);
    boolean excluir(int id);
    List<T> listar(int idContexto, String busca);
}